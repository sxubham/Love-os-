import React from 'react';

export default function LoveOSMobile() {
  return (
    <div className="h-screen w-full flex items-center justify-center bg-pink-100 text-center text-lg font-bold">
      LoveOS is loading... (final UI will go here)
    </div>
  );
}